import json
import os
from datetime import datetime
import boto3

TABLE_NAME = os.environ.get("DYNAMODB_TABLE", "ToDoList")

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(TABLE_NAME)

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
    except Exception:
        body = {}

    if not body.get("name"):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "O campo 'name' é obrigatório"})
        }

    name = body["name"]
    item = {
        "PK": f"LIST#{name}",
        "SK": f"CREATED_AT#{datetime.utcnow().isoformat()}",
        "name": name
    }

    table.put_item(Item=item)

    return {
        "statusCode": 201,
        "body": json.dumps({"message": "Lista criada", "item": item})
    }
