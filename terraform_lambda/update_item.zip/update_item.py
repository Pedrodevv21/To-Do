import json
import boto3
import os

dynamodb = boto3.client('dynamodb')
TABLE_NAME = os.environ['DYNAMODB_TABLE']

def lambda_handler(event, context):
    try:
        # Pega os valores 'pk' e 'sk' da URL path parameters
        pk_raw = event["pathParameters"]["pk"]   # ex: "9f7d558c-c59e-4560-b5fa-baec9d4ed343"
        sk_raw = event["pathParameters"]["sk"]   # ex: "49cba0b9-8840-4f9d-a7a4-7908d5e26238"

        # Monta as chaves completas
        pk = f"LIST#{pk_raw}"
        sk = f"ITEM#{sk_raw}"

        # Pega os dados do corpo da requisição (JSON)
        body = json.loads(event["body"])
        nome = body.get("name")
        status = body.get("status")

        # Monta o update expression e os valores para o DynamoDB
        update_expression = "SET #n = :name, #s = :status"
        expression_attribute_names = {
            "#n": "name",
            "#s": "status"
        }
        expression_attribute_values = {
            ":name": {"S": nome},
            ":status": {"S": status}
        }

        # Faz o update no DynamoDB
        response = dynamodb.update_item(
            TableName=TABLE_NAME,
            Key={
                "PK": {"S": pk},
                "SK": {"S": sk}
            },
            UpdateExpression=update_expression,
            ExpressionAttributeNames=expression_attribute_names,
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues="ALL_NEW"
        )

        # Retorna o item atualizado
        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "Item atualizado com sucesso",
                "updatedItem": response.get("Attributes")
            }),
            "headers": {
                "Content-Type": "application/json"
            }
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "message": "Erro ao atualizar item",
                "error": str(e)
            }),
            "headers": {
                "Content-Type": "application/json"
            }
        }







